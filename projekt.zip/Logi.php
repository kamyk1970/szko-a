<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
</head>
<body>
    <form method="POST">
    Login: <input type="text" name="login">
    Hasło:<input type="password" name="haslo">
    <button type="submit" name="log">LOG IN</button>
    <button type="submit" name="rej">SIGN UP</button>
    </form>

    <?php
    $conn = mysqli_connect("localhost", "root", "", "projekt");
    if (!$conn) {
    die("Błąd połączenia z bazą");
}

    if(isset($_POST['rej'])){
        $login = $_POST['login'];
        $haslo = $_POST['haslo'];
        $q1 = "INSERT INTO users(username, password) VALUES('$login', '$haslo');";
        $result1 = mysqli_query($conn, $q1);
    }

    if(isset($_POST['log'])){
        $login = $_POST['login'];
        $haslo = $_POST['haslo'];
        $q2 = "SELECT username, password FROM users where  username='$login' and password = '$haslo'";
        $result2 = mysqli_query($conn, $q2);
        if (mysqli_num_rows($result2) > 0) {
            $_SESSION['login'] = $login;
            header("Location: MainPage.php");
        } else {
            echo "Błędny login lub hasło!";
        }
    }
    ?>
</body>
</html>