<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
            body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 20px;
        }
        a.powrot {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .chatbox {
            width: 400px;
            background: white;
            padding: 20px;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        .wiadomosc {
            background: #e1ffe1;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
        }
        .ai {
            background: #d1d1ff;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
        }
        input {
            width: 10%;
            padding: 10px;
            margin-bottom: 10px;
        }
        nav {
            background-color: #eee;
            min-height: 500px;
            width: 15%;
            float: right;
            padding: 20px;
            box-sizing: border-box;
        }
        main {
            background-color: #ffffff67;
            min-height: 500px;
            width: 85%;
            float: left;
            padding: 20px;
            box-sizing: border-box;
            border-right: 1px solid #ddd;
        }      
    </style>
</head>
<body>
    <header id="prof">
        <img src="ikona.jpg" alt="">
    </header>
    <main id="lp">
        <h1>Lista Postów</h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "projekt");

        # ZAPIS DO BAZY
        if (isset($_POST["zawar"]) && $_POST["zawar"] !== "") {
            $p = $_POST["zawar"];
            $mysqli->query("INSERT INTO posty (tekst) VALUES ('$p')");
        }

        # ODCZYT Z BAZY
        $result = $mysqli->query("SELECT * FROM posty");

        while ($row = $result->fetch_assoc()) {
            echo "<p><strong>Post:</strong> " . $row["tekst"] . "</p>";
        }
        $mysqli->close();
        ?>
    </main>


    <footer>
        <form action="" id="tworzenie_postow" method="post">
            <label for="zawar" id="lab1">Stwórz własny post</label>
            <input type="text" name="zawar" placeholder="Wpisz tytuł posta">
            <button id="wysylanie" type="submit">Wyślij</button>
        </form>
    </footer>
    <nav>
        <h2>Mainpage</h2>
    </nav>
    
    <form method="post">
        <button type="submit" name="logout">Wyloguj</button>
    </form>
    <?php
    if(isset($_POST['logout'])){
        session_unset();
        session_destroy();
        header("Location: Logi.php");
    }
    ?>
</body>
</html>