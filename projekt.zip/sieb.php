<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 20px;
        }
        a.powrot {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .chatbox {
            width: 400px;
            background: white;
            padding: 20px;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        .wiadomosc {
            background: #e1ffe1;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
        }
        .ai {
            background: #d1d1ff;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<a href="sechs.php" class="powrot">← Powrót do strony głównej</a>

<h2>Chat z  Michałem</h2>

<div class="chatbox">

    <script>
    const chat = document.getElementById("chat");
    const form = document.getElementById("form");
    const msgInput = document.getElementById("msg");


    const odpowiedziAI = [
        "Cześć! Co u Ciebie słychać?",
        "Hmm, nie jestem pewien, ale spróbuj napisać coś innego.",
        "Super! Opowiedz mi więcej.",
        "Haha, dobre! A co dalej?",
        "Nie wiem dokładnie, ale mam nadzieję, że wszystko w porządku."
    ];

   
    function losowaOdpowiedz() {
        const indeks = Math.floor(Math.random() * odpowiedziAI.length);
        return odpowiedziAI[indeks];
    }

  
    form.addEventListener("submit", function(e) {
        e.preventDefault();

        const text = msgInput.value.trim();
        if (text === "") return;

        chat.innerHTML += `<div class='wiadomosc'>${text}</div>`;

        
        const ai = losowaOdpowiedz();
        chat.innerHTML += `<div class='wiadomosc ai'>AI: ${ai}</div>`;

        msgInput.value = "";
        chat.scrollTop = chat.scrollHeight;
    });
    </script>

    <form method="post">
        <input type="text" name="msg" placeholder="Napisz wiadomość...">
        <button type="submit">Wyślij</button>
    </form>

</div>

</body>
</html>
